
# What is this?

ECU CAN definitions for EGS53 compatibility (2008+ vehicles with EGS53 TCM)